# Search-Package
Multithreaded SEARCH package ( jump search, fibonacci search, exponential search and Interpolation search) is an java application which is interactive and demonstrate the working of the algorithm in a step wise fashion.
